<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database1 = "admin";
$database2 = "payment";
$conn1 = mysqli_connect($servername, $username, $password, $database1);
if ($conn1->connect_error) {
    die("Connection to database1 failed: " . $conn1->connect_error);
}
$conn2 = mysqli_connect($servername, $username, $password, $database2);
if ($conn2->connect_error) {
    die("Connection to database2 failed: " . $conn2->connect_error);
}

$id = null;
$id2 = null;

if ($_SESSION['loginemail'] == true) {
    $user = $_SESSION['loginemail'];
    $sql = "SELECT degree_name, degree_year FROM `userdata` WHERE email = '$user'";
    $result = mysqli_query($conn2, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $id = mysqli_fetch_assoc($result);
        $degree = $id['degree_name'];
        $year = $id['degree_year'];

        $sql = "USE $database1";
        $result = mysqli_query($conn1, $sql);
        if ($result) {
            $sql = "SELECT * FROM `fees` WHERE course='$degree' AND course_year= '$year'";
            $result = mysqli_query($conn1, $sql);

            if ($result && mysqli_num_rows($result) > 0) {
                $id = mysqli_fetch_assoc($result);
                $feeamount = $id["fee_amount"];
            } else {
                echo "No data found in fees table";
            }
            $sql = "SELECT * FROM `emi_table` WHERE course_name='$degree' AND course_year= '$year'";
            $result = mysqli_query($conn1, $sql);

            if ($result && mysqli_num_rows($result) > 0) {
                $id2 = mysqli_fetch_assoc($result);
                $firstamount = $id2["first_installment_amount"];
                $firstdate = $id2["first_installment_date"];
                $secondamount = $id2["second_installment_amount"];
                $seconddate = $id2["second_installment_date"];
                $thirdamount = $id2["third_installment_amount"];
                $thirddate = $id2["third_installment_date"];
            } else {
                echo "No data found in emi_table";
            }
        } else {
            echo "Failed to switch to database1";
        }
    }
}

$selected_installment = "";
$full = ("full");
$first = ("first");
$second= ("second");
$third = ("third");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST["installment_selection"])) {
        $selected_installment = $_POST["installment_selection"];
        $_SESSION["selected_installment"] = $selected_installment;
        if($selected_installment== $full)
        {
            $_SESSION["amount"] = $feeamount;
        }
        elseif($selected_installment == $first)
        {
            $_SESSION["amount"] = $firstamount;
        }
        elseif($selected_installment == $second)
        {
            $_SESSION["amount"] = $secondamount;
        }
        elseif($selected_installment == $third)
        {
            $_SESSION["amount"] = $thirdamount;
        }
        else{
            echo "Select the amount";
        }
        header("Location: payment.php");
        
    }
}
mysqli_close($conn1);
mysqli_close($conn2);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fee Amount and EMI table </title>
    <style>
        h1{
            text-align: center;
            color:rgb(5, 68, 104);
        }
        table{
            margin: auto;
            margin-top: 100px;
        }
        th, td{
            padding:10px;
            color:rgb(5, 68, 104);
        }
        form{
            text-align: center;
            margin-top: 50px;
        }
        p,label{
            font-size: 20px;
        }
        .but{
            padding:8px;
            background-color:rgb(5, 68, 104);
            color: white;
            margin-top: 30px;
            width: 100px;
        }
        
        
        
        </style>
</head>

<body>
    <h1>Fee Amount And EMI </h1>
    <?php if ($id !== 'null' && $id2 !== 'null') { ?>
        <table border=2>
            <tr>
                <th colspan="2">Name Of The Course And Year</th>
                <th>Total Amount</th>
                <th colspan="2">Ist Installment</th>
                <th colspan="2">IInd Installment</th>
                <th colspan="2">IIIrdInstallment</th>
            </tr>
            <tr>
                <th>Course</th>
                <th>Year</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Amount</th>
            </tr>
            <tr>
                <td><?php echo "$degree"?></td>
                <td><?php echo "$year"?></td>
                <td><?php echo "$feeamount"?></td>
                <td><?php echo "$firstdate"?></td>
                <td><?php echo "$firstamount"?></td>
                <td><?php echo "$seconddate"?></td>
                <td><?php echo "$secondamount"?></td>
                <td><?php echo "$thirddate"?></td>
                <td><?php echo "$thirdamount"?></td>

    </tr>
        </table>
        <form method="post">
        <p>Select an installment:</p>
        <input type="radio" id="fullpayment" name="installment_selection" value="full">
        <label for="fullpayment">Full Payment</label><br>

        <input type="radio" id="first_installment" name="installment_selection" value="first">
        <label for="first_installment">First Installment</label><br>

        <input type="radio" id="second_installment" name="installment_selection" value="second">
        <label for="second_installment">Second Installment</label><br>

        <input type="radio" id="third_installment" name="installment_selection" value="third">
        <label for="third_installment">Third Installment</label><br>

        <input type="submit" value="Select" class="but">
    </form>

    <?php } ?>
</body>

</html>