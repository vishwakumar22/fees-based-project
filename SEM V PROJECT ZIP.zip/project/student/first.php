<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database = "payment";
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$id = null;
$id1 = null;
$data = array();
if ($_SESSION["loginemail"] == true) {
    $user = $_SESSION['loginemail'];
    $sql = "SELECT * FROM `paid` WHERE email= '$user'";
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
    } else {
        echo "No data found";
    }
    $sql = "SELECT name1, degree_name, degree_year FROM `userdata` WHERE email='$user'";
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) > 0) {
        $id1 = mysqli_fetch_assoc($result);
        $firstname = $id1["name1"];
        $graduationDegree = $id1["degree_name"];
        $graduationYear = $id1["degree_year"];
    } else {
        echo "No data found";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction History</title>
    <style>
        table{
            margin:auto;
        }
        th, td{
            padding:10px;
        }
        td{
            text-align: center;
        }
        button{
            background-color: rgb(5, 68, 104);
            color:white;
        }
        </style>
</head>

<body>
    <h1>History Of Transaction</h1>
    <?php if ($id1 !== null) { ?>
        <table border="2">
            <tr>
                <th>Name</th>
                <th>Year of Graduation</th>
                <th>Name of Degree</th>
                <th>Fee Amount paid</th>
                <th>Get Receipt</th>
            </tr>
            <tr>
                <td><?php echo "$firstname" ?></td>
                <td><?php echo " $graduationDegree "?></td>
                <td><?php echo "$graduationYear" ?></td>
                <?php foreach ($data as $row) { ?>
                    <td><?php echo $row["emi_amount"] ?></td>
                <?php } ?>
                <td><a href="receipt.php"><button>Get Receipt</button></a></td>
            </tr>
        </table>
    <?php } ?>
</body>

</html>
