<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database = "payment";
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$id3 = null;
$id = null;
$id1 = null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Receipt</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        body {
            color: rgb(5, 68, 104);
        }

        .but {
            display: flex;
        }

        .design {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .design h1 {
            font-size: 30px;
            margin-top: 100px;
        }

        .design p {
            font-size: 20px;
        }

        table {
            max-width: 800px;
            width: 100%;
            height: 600px;
        }

        td,
        th {
            padding: 10px;
        }

        td {
            font-size: 20px;
        }

        th {
            font-size: 30px;
            background-color: rgb(5, 68, 104);
            color: white;
        }

        .clkbtn {
            height: 60px;
            width: 150px;
            border-radius: 50px;
            background-color: rgb(5, 68, 104);
            font-size: 22px;
            color: white;
            border: none;
            cursor: pointer;
            position: relative;
            top: 20px;
            left: 100px;
        }
    </style>
</head>

<body>
    <div class="but">
        <button onclick="generatePdf()" class="clkbtn">Download Receipt</button>
        <a href="panel.html"><button class="clkbtn">Back to Dashboard</button></a>
    </div>
    <div id="invoice" class="design">
        <?php
        if ($_SESSION['loginemail'] == true) {
            $user = $_SESSION['loginemail'];
        }
        $sql = "SELECT * FROM `paid` WHERE email = '$user'";
        $result = mysqli_query($conn, $sql);
        if ($result && mysqli_num_rows($result) > 0) {
            $id3 = mysqli_fetch_assoc($result);
            $emiamount = $id3["emi_amount"];
            $method = $id3["payment_method"];
        }
        if ($method == "cardpayment") {
            $sql = "SELECT * FROM `cardpayment` WHERE email = '$user'";
            $result = mysqli_query($conn, $sql);
            if ($result && mysqli_num_rows($result) > 0) {
                $id1 = mysqli_fetch_assoc($result);
                $holdername = $id1["cardholder_name"];
                $number = $id1["card_number"];
                $expiry = $id1["expirydate"];
            } else {
                echo "No data found";
            }
        } elseif ($method == "bankpayment") {
            $sql = "SELECT * FROM `bankpayment` WHERE email = '$user'";
            $result = mysqli_query($conn, $sql);
            if ($result && mysqli_num_rows($result) > 0) {
                $id1 = mysqli_fetch_assoc($result);
                $accholdername = $id1["accountholder_name"];
                $accnumber = $id1["account_number"];
                $bankname = $id1["bankname"];
            } else {
                echo "No data found";
            }
        }
        $sql = "SELECT * FROM `userdata` WHERE email='$user'";
        $result = mysqli_query($conn, $sql);
        if ($result && mysqli_num_rows($result) > 0) {
            $id = mysqli_fetch_assoc($result);
            $fullname = $id["name1"];
            $gender = $id["gender"];
            $dob = $id["dob"];
            $degree_name = $id["degree_name"];
            $degree_year = $id["degree_year"];
        } else {
            echo "No data found";
        }

        ?>
        <h1>XYZ College</h1>
        <p>Payment Receipt</p>
        <table border=2>
            <tr>
                <th colspan="3">Personal Details</th>
            </tr>
            <tr>
                <td colspan="3"> Name :
                    <?php echo "$fullname" ?>
                </td>
            </tr>
            <tr>
                <td>Gender :
                    <?php echo "$gender" ?>
                </td>

                <td>Dob :
                    <?php echo "$dob" ?>
                </td>
            </tr>
            <tr>
                <td colspan="3">Course and Year:
                    <?php echo "  $degree_name $degree_year " ?>
                </td>
            </tr>
            <tr>
                <th colspan="3">Payment Method </th>
            </tr>
            <tr>
                <td colspan="3"> Payment Method :
                    <?php echo "$method" ?>
                </td>
            </tr>
            <?php if ($method == "cardpayment") { ?>
                <tr>
                    <td colspan="3">Card Holder Name :
                        <?php echo "$holdername" ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">Card Number :
                        <?php echo "$number" ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">Expiry Date :
                        <?php echo "$expiry" ?>
                    </td>
                </tr>
            <?php } ?>
            <?php if ($method == "bankpayment") { ?>
                <tr>
                    <td colspan="3">Bank Account Holder Name :
                        <?php echo "$accholdername" ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">Account Number :
                        <?php echo "$accnumber" ?>
                    </td>
                </tr>
                <tr>
                    <td colspan="3">Bank Name :
                        <?php echo "$bankname" ?>
                    </td>
                </tr>
            <?php } ?>
            <tr>
                <td colspan="3">Amount paid :
                    <?php echo "$emiamount" ?>
                </td>
            </tr>
        </table>

    </div>

    <script>
        function generatePdf() {
            const element = document.getElementById("invoice");
            html2pdf()
                .from(element)
                .save();
        }
    </script>
</body>

</html>