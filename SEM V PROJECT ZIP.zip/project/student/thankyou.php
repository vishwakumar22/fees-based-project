<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css' rel='stylesheet'>
    <title>Document</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0px;
        }

        body {
            background-color: rgb(5, 68, 104);
        }

        .icon {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .icon i {
            font-size: 200px;
            position: relative;
            top: 130px;
            color: white;
        }

        .icon p {
            text-transform: capitalize;
            font-size: 30px;
            position: relative;
            top: 170px;
            color: white;
        }
        a{
            text-decoration: none;
        }
    </style>
</head>

<body>
    <a href="panel.html">
        <div class="icon">
            <i class="fa-solid fa-circle-check"></i>
            <p>Registered successfully </p>
        </div>
    </a>
</body>

</html>