<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "payment";
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
session_start();
$id = null;
if ($_SESSION['loginemail'] == true) {
    $user = $_SESSION['loginemail'];
    $sql = "SELECT * FROM `userdata` where email = '$user'";
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) > 0) {
        $id = mysqli_fetch_assoc($result);
        $fullname = $id["name1"];
        $dob = $id["dob"];
        $email = $id["email"];
        $gender = $id["gender"];
        $school_name = $id["school_name"];
        $school_year = $id["school_year"];
        $jr_college_name = $id["jr_college_name"];
        $jr_passout_year = $id["jr_passout_year"];
        $institution_name = $id["institution_name"];
        $degree_name = $id["degree_name"];
        $degree_year = $id["degree_year"];
        $address = $id["address1"];
        $fathername = $id["fathername"];
        $mothername = $id["mothername"];
        $parent_contact = $id["parentnumber"];
        $emergency_name = $id["emergencyname"];
        $emergency_contact = $id["emergencynumber"];
        // date
        $date = $id["date"];
        $newyear = date("Y-06-15");
        list($currentYear, $currentMonth, $currentDay) = explode("-", $date);
        list($yearYear, $yearMonth, $yearDay) = explode("-", $newyear);
        $yearDifference = $yearYear - $currentYear;

    } else {
        echo "No data found";
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <style>
        body {
            background-color: white;
            font-size: 20px;
        }

        .head {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .head p {
            font-size: 30px;
            text-transform: capitalize;
            margin-top: 10px;
        }

        .table {
            margin: auto;
            margin-top: 40px;
            max-width: 1000px;
            width: 100%;
            border: 2px solid rgb(5, 68, 104);
            color: rgb(5, 68, 104);
        }

        th,
        td {
            padding: 10px;
        }

        th {
            font-size: 30px;
            background-color: rgb(5, 68, 104);
            color: white;
        }

        .subhead {
            font-size: 20px;
            background-color: rgb(5, 68, 104);
            color: white;
        }

        .but {
            margin: 50px 550px;
            padding: 10px;
            background-color: rgb(5, 68, 104);
            color: white;
            /*position: relative;
            top: 40px;
            left: 500px;*/

        }
    </style>
</head>

<body>
    <?php if ($id !== null) { ?>
        <div class="head">
            <p>Vishwakarma University </p>
            <p>Student Profile</p>
        </div>
        <table border="2" class="table">
           
            <tr>
                <th colspan="3">Personal information</th>
            </tr>
            <tr>
                <td colspan="3">fullName :
                    <?php echo "$fullname"; ?>
                </td>
            </tr>
            <tr>
                <td>Gender :
                    <?php echo "$gender" ?>
                <td>Email :
                    <?php echo "$email" ?>
                <td>DOB :
                    <?php echo "$dob" ?>
            </tr>
            <tr>
                <th colspan="3">Address Details</th>
            </tr>
            <tr>
                <td colspan="2">address:
                    <?php echo "$address" ?>
                </td>
            </tr>
            
            <tr>
                <th colspan="3">Parents Details</th>
            </tr>
            <tr>
                <td colspan="2">father Name :
                    <?php echo "$fathername" ?>
                </td>
                <td colspan="2">mother Name :
                    <?php echo "$mothername" ?>
                </td>
    </tr>
    <tr>
                <td colspan="2">Parents contact Number :
                    <?php echo "$parent_contact" ?>
                </td>
            </tr>
            <tr>
                <td colspan="2">Emergency Contact Name :
                    <?php echo "$emergency_name" ?>
                </td>
                <td colspan="2">Emergency Contact Number :
                    <?php echo "$emergency_contact" ?>
                </td>
            </tr>
            
            <tr>
                <th colspan="3">Education Details</th>
            </tr>
            <tr>
                <th colspan="3" class="subhead">High Education Details</th>
            </tr>
            <tr>
                <td colspan="2">School Name :
                    <?php echo "$school_name" ?>
                </td>
                <td colspan="2">Passout year :
                    <?php echo "$school_year" ?>
                </td>
            </tr>
            
            <tr>
                <th colspan="3" class="subhead">Secondary Education Details</th>
            </tr>
            <tr>
                <td colspan="2">Junior College Name :
                    <?php echo "$jr_college_name" ?>
    </td>
                <td colspan="2">Junior College Passout year :
                    <?php echo "$jr_passout_year" ?>
                </td>
            </tr>
            <tr>
                <th colspan="3" class="subhead">Graduation Details</th>
            </tr>

            <tr>
                <td colspan="2">Degree Name :
                    <?php echo "$degree_name" ?>
                </td>
                <td colspan="2">Graduation year :
                    <?php if ($yearDifference == 1) {
                        if ($degree_year == "fy") {
                            $sql = "UPDATE `userdata` SET `degree_year` = 'SY' WHERE email='$user' ";
                            $result = mysqli_query($conn, $sql);
                        } 
                        elseif ($degree_year == "sy") {
                            $sql = "UPDATE `userdata` SET `degree_year` = 'SY' WHERE email='$user' ";
                            $result = mysqli_query($conn, $sql);
                        } 
                        elseif ($degree_year== "ty") {
                            echo $degree_year == "ty";
                        }
                    } else {
                    echo "$degree_year"; } ?>
                    
                </td>
            </tr>
            <tr>
                <td colspan="3">Graduation Name:
                    <?php echo "$institution_name" ?>
                </td>
            </tr>
        </table>

    <?php } ?>

    <a href='panel.html'><button class="but">Back to Dashboard</button></a>
</body>

</html>