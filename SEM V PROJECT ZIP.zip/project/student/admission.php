<?php
$servername="localhost";
$username = "root";
$password = "";
$database = "payment";

$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn -> connect_error)
{
    die ("Connection failed : ". $conn->connect_error);
}
// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['submit'])) { // Check if the submit button was clicked

        // Retrieve form data
        $fullname = $_POST["fullname"];
        $dob = $_POST["dob"];
        $email = $_POST["email"];
        $gender = $_POST["gender"];
        $school_name = $_POST["schoolname"];
        $school_year = $_POST["schoolyear"];
        $jr_college_name = $_POST["jrcollegename"];
        $jr_passout_year = $_POST["passoutyear"];
        $institution_name = $_POST["institutionname"];
        $degree_name = $_POST["degree_name"];
        $degree_year = $_POST["degree_year"];
        $address = $_POST["address"];
        $fathername = $_POST["fathername"];
        $mothername = $_POST["mothername"];
        $parent_contact = $_POST["parentcontact"];
        $emergency_name = $_POST["emergencyname"];
        $emergency_contact = $_POST["emergencynumber"];
        $sql = "INSERT INTO `userdata` (name1, dob, email, gender, school_name, school_year, jr_college_name, jr_passout_year, institution_name, degree_name, degree_year, address1, fathername, mothername, parentnumber, emergencyname, emergencynumber) VALUES ('$fullname', '$dob', '$email', '$gender', '$school_name', '$school_year', '$jr_college_name', '$jr_passout_year', '$institution_name', '$degree_name', '$degree_year', '$address', '$fathername', '$mothername', '$parent_contact', '$emergency_name', '$emergency_contact')";
        
        $result = mysqli_query($conn, $sql);
        
        if ($result) {
            echo "Record inserted successfully";
        } else {
            echo "Failed to insert record";
        }
    }
}

mysqli_close($conn);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Details Form</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 800px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
}

h1 {
    text-align: center;
}

form {
    margin-top: 20px;
}

section {
    margin-bottom: 20px;
}

h2 {
    font-size: 20px;
    margin-bottom: 10px;
}

.form-group {
    margin-bottom: 15px;
}

label {
    font-weight: bold;
}

input[type="text"],
input[type="date"],
input[type="number"],
input[type="tel"],
select,
textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
}

textarea {
    resize: vertical;
}

.submit-button {
    text-align: center;
}

button {
    padding: 10px 20px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    font-size: 18px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}
.head{
    text-align: center;
    background-color: #0056b3;
    color:white;
    font-size: 30px;
}
h3{
    font-size: 20px;
    background-color:#ccc ;
    color:black;
    text-align: center;
}
</style>
</head>
<body>
    <div class="container">
        <h1>Student Details Form</h1>
        <form method="post" action="admission.php">
            <section>
                <h2 class="head">Personal Information</h2>
                <div class="form-group">
                    <label for="fullName">Full Name:</label>
                    <input type="text" id="fullName" placeholder="John Doe" name="fullname" required>
                </div>
                <div class="form-group">
                    <label for="dob">Date of Birth:</label>
                    <input type="date" id="dob" name="dob" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="gender">Gender:</label>
                    <select id="gender" name="gender" required>
                        <option value="male" name="gender">Male</option>
                        <option value="female" name="gender">Female</option>
                        <option value="other" name="gender">Other</option>
                    </select>
                </div>
            </section>

            <section>
                <h2 class="head">Education Details</h2>
                <h3>school infromation</h3>
                <div class="form-group">
                    <label for="schoolName">School Name:</label>
                    <input type="text" id="schoolName" name="schoolname" placeholder="XYZ High School" required>
                </div>
                <div class="form-group">
                    <label for="schoolyear">School Passout year:</label>
                    <input type="number" id="schoolyear" name="schoolyear" placeholder="XYZ High School" required>
                </div>
                <h3>Higher Education details</h3>
                <div class="form-group">
                    <label for="jrName">Junior College year Name:</label>
                    <input type="text" id="jrName" name="jrcollegename" placeholder="XYZ High School" required>
                </div>
                <div class="form-group">
                    <label for="jryear">Passout year :</label>
                    <input type="number" id="jryear" name="passoutyear" placeholder="2023" required>
                </div>
                <h3>Graduation Education details</h3>
                <div class="form-group">
                    <label for="collegeName">Institution  Name:</label>
                    <input type="text" id="collegeName" name="institutionname" placeholder="XYZ High School" required>
                </div>
                <div class="form-group">
                    <label for="degreename">Degree :</label>
                    <input type="text" id="degreename" name="degree_name" placeholder="degree name" required>
                </div>
                <div class="form-group">
                    <label for="gradYear">Degree year :</label>
                    <input type="text" id="gradYear" name="degree_year" placeholder="Fy, Sy, Ty" required>
                </div>
            </section>

            <section>
                <h2 class="head">Address Details</h2>
                <div class="form-group">
                    <label for="address">Address:</label>
                    <textarea id="address" rows="3" name="address" placeholder="123 Main St, City, Country" required></textarea>
                </div>
            </section>

            <section>
                <h2 class="head">Parents Information</h2>
                <div class="form-group">
                    <label for="fatherName">Father's Name:</label>
                    <input type="text" id="fatherName" name="fathername" placeholder="John Doe Sr." required>
                </div>
                <div class="form-group">
                    <label for="motherName">Mother's Name:</label>
                    <input type="text" id="motherName" name="mothername" placeholder="Jane Doe" required>
                </div>
                <div class="form-group">
                    <label for="parentContact">Parent's Contact Number:</label>
                    <input type="tel" id="parentContact" name="parentcontact" placeholder="+1 (123) 456-7890" required>
                </div>
            </section>

            <section> 
                <h2 class="head">Emergency Contact</h2>
                <div class="form-group">
                    <label for="emergencyName">Emergency Contact Name:</label>
                    <input type="text" id="emergencyName" name="emergencyname" placeholder="Emergency Contact Name" required>
                </div>
                <div class="form-group">
                    <label for="emergencyContact">Emergency Contact Number:</label>
                    <input type="tel" id="emergencyContact" name="emergencynumber" placeholder="+1 (987) 654-3210" required>
                </div>
            </section>

            <div class="form-group submit-button">
                <button type="submit" name="submit">Submit</button>
            </div>
        </form>
        <a href="panel.html"><button class="submit-button">Back To Dashboard</button></a>
    </div>
</body>
</html>
