<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "payment";
$database1 = "admin";
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn1 = mysqli_connect($servername, $username, $password, $database1);
if ($conn1->connect_error) {
    die("Connection to database1 failed: " . $conn1->connect_error);
}

$addmsg = null;
$id = null;
if ($_SESSION['loginemail'] == true) {
    $user = $_SESSION['loginemail'];
    $amount = $_SESSION["amount"];
    $paymentmethod = " ";
    $sql = "SELECT degree_name, degree_year FROM `userdata` WHERE email = '$user'";
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) > 0) {
        $id = mysqli_fetch_assoc($result);
        $degree = $id['degree_name'];
        $year = $id['degree_year'];
        $sql = "USE $database1";
        $result = mysqli_query($conn1, $sql);
        if ($result) {
            $sql = "SELECT * FROM `fees` WHERE course='$degree' AND course_year= '$year'";
            $result = mysqli_query($conn1, $sql);
            if ($result && mysqli_num_rows($result) > 0) {
                $id = mysqli_fetch_assoc($result);
                $feeamount = $id["fee_amount"];
            } else {
                echo "No data found in fees table";
            }
            $sql = "SELECT * FROM `emi_table` WHERE course_name='$degree' AND course_year= '$year'";
            $result = mysqli_query($conn1, $sql);

            if ($result && mysqli_num_rows($result) > 0) {
                $id2 = mysqli_fetch_assoc($result);
                $firstamount = $id2["first_installment_amount"];
                $firstdate = $id2["first_installment_date"];
                $secondamount = $id2["second_installment_amount"];
                $seconddate = $id2["second_installment_date"];
                $thirdamount = $id2["third_installment_amount"];
                $thirddate = $id2["third_installment_date"];
            } else {
                echo "No data found in emi_table";
            }
        }
    }
    $sql = "SELECT * FROM `paid` WHERE email = '$user' ";
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) > 0) {
        $id = mysqli_fetch_assoc($result);
        $paidamount = $id["emi_amount"];
        if ($paidamount == $feeamount) {
            $addmsg = "You have already paid the full amount. Thank you!";
        } elseif ($paidamount == $firstamount) {
            $addmsg = "You have already paid the $firstamount amount. Wait until $seconddate  to pay $secondamount.Thank you!";
        } elseif ($paidamount == $secondamount) {
            $addmsg = "You have already paid the $secondamount amount. Wait until $thirddate  to pay $thirdamount.Thank you!";
        } elseif ($paidamount == $thirdamount) {
            $addmsg = "You have already paid the No Amount has left to pay.Thank you!";
        }else{
            $addmsg = "No data found";
        }
    }
    elseif ($result && mysqli_num_rows($result) == 0) {
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                if (isset($_POST["cardpayment"])) {
                    $paymentmethod = 'cardpayment';
                    $Name = $_POST["name"];
                    $Number = $_POST["number"];
                    $expiry = $_POST["expirydate"];
                    $cvv = $_POST["cvv"];
                    if (!empty($Name) && strlen($Number) === 16 && strlen($expiry) === 4 && strlen($cvv) === 3) {
                        $sql = "INSERT INTO `cardpayment` (cardholder_name, card_number, expirydate, cvv, email) VALUES ('$Name', '$Number', '$expiry', '$cvv', '$user')";
                        $result = mysqli_query($conn, $sql);
                        if ($result) {
                            $sql = "INSERT INTO `paid` (emi_amount, payment_method, email) VALUES ('$amount', '$paymentmethod', '$user')";
                            $result = mysqli_query($conn, $sql);
                            if ($result) {
                                header("Location:thankyou.php ");
                            }
                        }
                    } else {
                        echo "Fill the data properly";
                    }
                } elseif (isset($_POST["bankpayment"])) {
                    $paymentmethod = 'bankpayment';
                    $holdername = $_POST["holder-name"];
                    $accnumber = $_POST["account-number"];
                    $bankname = $_POST["bank-name"];
                    if (!empty($holdername) && strlen($accnumber) >= 9 && strlen($accnumber) <= 18 && !empty($bankname)) {
                        $sql = "INSERT INTO `bankpayment` (accountholder_name, account_number, bankname, email) VALUES ('$holdername', '$accnumber', '$bankname', '$user')";
                        $result = mysqli_query($conn, $sql);
                        if ($result) {
                            $sql = "INSERT INTO `paid` (emi_amount, payment_method, email) VALUES ('$amount', '$paymentmethod', '$user')";
                            $result = mysqli_query($conn, $sql);
                            if ($result) {
                                header("Location:thankyou.php ");
                            }
                        } else {
                            echo "Failed to pay: " . mysqli_error($conn);
                        }
                    } else {
                        echo "Fill the details properly";
                    }
                }
                $_SESSION['paymentmethod'] = $paymentmethod;

            }
        }
    }




$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>payment</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .container {
            height: 400px;
            width: 700px;
            background-color: white;
            box-shadow: 8px 8px 20px rgb(128, 128, 128);
            position: relative;
            left: 300px;
            overflow: hidden;
            top: 120px;
            border-radius: 25px;
        }

        .btn1 {
            height: 60px;
            max-width: 700px;
            width: 100%;
            margin: 0px auto;
            box-shadow: 10px 10px 30px rgb(5, 68, 104);
            border-radius: 50px;
            display: flex;
            justify-content: space-around;
            align-items: center;
            background-color: #d6d4e0;
        }

        .cardpay,
        .bankpay {
            font-size: 20px;
            color: white;
            border: none;
            outline: none;
            background-color: transparent;
            position: relative;
            cursor: pointer;
        }

        .slider {
            height: 60px;
            width: 300px;
            border-radius: 50px;
            background-color: rgb(5, 68, 104);
            position: absolute;
            transition: all 0.1s linear;
        }

        .moveslider {
            left: 400px;
        }

        .payment {
            height: 300px;
            width: 600px;
            padding: 10px;
            display: flex;
            position: relative;
            top: 30px;
            left: 50px;
            transition: all 0.9s ease-in-out;

        }

        .label {
            font-size: 20px;
            margin-right: 20px;
        }

        .ele {
            height: 50px;
            width: 250px;
            outline: none;
            border: none;
            color: rgb(77, 77, 77);
            background-color: rgb(240, 240, 240);
            border-radius: 50px;
            padding-left: 30px;
            font-size: large;
            margin-bottom: 10px;
        }

        .one {
            display: flex;
            position: relative;
            margin-top: 10px;
            gap: 30px;
        }

        .account {
            position: relative;
            left: 170px;
        }

        .account div {
            display: flex;
            flex-direction: row;
        }

        .clkbtn {
            height: 40px;
            width: 150px;
            border-radius: 50px;
            background-color: rgb(5, 68, 104);
            font-size: 22px;
            color: white;
            border: none;
            cursor: pointer;
            position: relative;
            top: 20px;
            left: 200px;
        }

        .payment-move {
            left: -600px;
        }

        .exit {
            padding: 10px;
            background-color: rgb(5, 68, 104);
            color: white;
            border-radius: 50px;
            position: relative;
            top: 20px;
            left: 50px;

        }

        .addmsg {
            font-size: 20px;
            color: rgb(5, 68, 104);
            text-align: center;
        }
    </style>
</head>

<body>
    <p class="addmsg">
        <?php echo "$addmsg" ?>
    </p>
    <div class="container">
        <div class="slider"></div>
        <div class="btn1">
            <button class="cardpay">Card Payment</button>
            <button class="bankpay">Bank Transfer</button>
        </div>
        <div class="payment">

            <form class="box" method="post">
                <div>
                    <label for="card" class="label">Cardholder Name:- </label>
                    <input type='text' placeholder="XYZ" id="card" name="name" class="ele" required>
                </div>
                <div>
                    <label for="cardnum" class="label">Card Number:- </label>
                    <input type='number' placeholder="xxxx xxxx xxxx xxxx" id="cardnum" name="number" class="ele"
                        required>
                </div>
                <div class=" one">
                    <div>
                        <label for="expiry" class="label">Expiry Date:- </label>
                        <input type='number' placeholder="MM/YY" id="expiry" name="expirydate" class="ele" required>
                    </div>
                    <div>
                        <label for="cvv" class="label">CVV:- </label>
                        <input type='number' placeholder="xxx" id="cvv" name="cvv" class="ele" required>
                    </div>
                </div>
                <button class="clkbtn" name="cardpayment">Pay</button>
            </form>
            <form class="account" method="post">
                <div>
                    <label for="account-holder" class="label">CardHolder Name:- </label>
                    <input type="text" id="account-holder" class="ele" name="holder-name" placeholder="XYZ" required>
                </div>
                <div>
                    <label for="account-number" class="label">Account Number:-</label>
                    <input type="text" id="account-number" class="ele" name="account-number" placeholder="1234567890"
                        required>
                </div>
                <div>
                    <label for="bank-name" class="label">Bank Name:-</label>
                    <input type="text" id="bank-name" class="ele" name="bank-name" placeholder="ABC Bank" required>
                </div>
                <button type="submit" class="clkbtn" name="bankpayment">Pay </button>
            </form>
        </div>
    </div>
    <a href="panel.html"><button class="exit">Back To Dashboard</button></a>

    <script>
        let card = document.querySelector(".cardpay");
        let bank = document.querySelector(".bankpay");
        let slider = document.querySelector(".slider");
        let payment = document.querySelector(".payment");

        bank.addEventListener("click", () => {
            slider.classList.add("moveslider");
            payment.classList.add("payment-move");
        });
        card.addEventListener("click", () => {
            slider.classList.remove("moveslider");
            payment.classList.remove("payment-move");
        });

    </script>
</body>

</html>