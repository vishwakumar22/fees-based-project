<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "payment";
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("connection failed : " . $conn->connect_error);
}
$id = null;
if (isset($_POST["find"])) {
    $user = $_POST["search"];
    $sql = "SELECT * FROM `userdata` WHERE email= '$user'";
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) > 0) {
        $id = mysqli_fetch_assoc($result);
        $title = $id["title"];
        $firstname = $id["first_name"];
        $lastname = $id["last_name"];
        $gender = $id["gender"];
        $dob = $id["dob"];
        $state = $id["state1"];
        $city = $id["city"];
        $room = $id["room"];
        $street = $id["street"];
        $pincode = $id["pincode"];
        $email = $id["email"];
        $phoneNumber = $id["phone_number"];
        $parentName = $id["parent_name"];
        $parentPhoneNumber = $id["parent_phone_number"];
        $schoolName = $id["school_name"];
        $schoolYear = $id["school_year"];
        $schoolBoardName = $id["school_board_name"];
        $jrCollegeName = $id["jr_college_name"];
        $stream = $id["stream"];
        $jrCollegeBoardName = $id["jr_college_board_name"];
        $jrCollegeYear = $id["jr_college_year"];
        $graduationDegree = $id["graduation_degree"];
        $graduationYear = $id["graduation_year"];
        $graduationInstitution = $id["graduation_institution"];
        $emergencyContactName = $id["emergency_contact_name"];
        $emergencyContactNumber = $id["emergency_contact_number"];
    }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search </title>
    <style>
        input {
            padding: 10px;
            width: 800px;
            margin-left: 150px;
        }

        button {
            padding: 5px;
            background-color: rgb(5, 68, 104);
            ;
            color: white;
            margin: 10px;
        }

        .head {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            font-size: 20px;
        }

        .table {
            margin: auto;
            margin-top: 40px;
            max-width: 1200px;
            width: 100%;
            border: 2px solid rgb(5, 68, 104);
            color: rgb(5, 68, 104);
        }

        th {
            background-color: rgb(5, 68, 104);
            color: white;
        }
    </style>
</head>

<body>
    <a href="dashboard.html"><button>Dashboard</button></a>
    <form method="post" action="search.php">
        <input type="search" placeholder="Search student using email id eg:efg@gmail.com" name="search">
        <button name="find">Search</button>

    </form>
    <?php if ($id !== null) { ?>
        <div class="head">
            <p>Student Profile</p>
        </div>
        <table border="2" class="table">
            <tr>
                <td colspan="4">Here image will display</td>
            </tr>
            <tr>
                <th colspan="4">Personal information</th>
            </tr>
            <tr>
                <td colspan="2">FirstName :
                    <?php echo "$firstname"; ?>
                </td>
                <td colspan="2">LastName :
                    <?php echo "$lastname" ?>
                </td>
            </tr>
            <tr>
                <td>Gender :
                    <?php echo "$gender" ?>
                <td>Email :
                    <?php echo "$email" ?>
                <td>DOB :
                    <?php echo "$dob" ?>
                <td>Contact number :
                    <?php echo "$phoneNumber" ?>
            </tr>
            <tr>
                <th colspan="4">Address Details</th>
            </tr>
            <tr>
                <td colspan="2">State :
                    <?php echo "$state" ?>
                </td>
                <td colspan="2">City :
                    <?php echo "$city" ?>
                </td>
            </tr>
            <tr>
                <td>Room no :
                    <?php echo "$room" ?>
                </td>
                <td colspan="2">Street :
                    <?php echo "$street" ?>
                </td>
                <td>Pincode :
                    <?php echo "$pincode" ?>
                </td>
            </tr>
            <tr>
                <th colspan="4">Parents Details</th>
            </tr>
            <tr>
                <td colspan="2">Parent Name :
                    <?php echo "$parentName" ?>
                </td>
                <td colspan="2">Parents contact Number :
                    <?php echo "$parentPhoneNumber" ?>
                </td>
            </tr>
            <tr>
                <td colspan="2">Emergency Contact Name :
                    <?php echo "$emergencyContactName" ?>
                </td>
                <td colspan="2">Emergency Contact Number :
                    <?php echo "$emergencyContactNumber" ?>
                </td>
            </tr>
            <tr>
                <th colspan="4">Education Details</th>
            </tr>
            <tr>
                <th colspan="4" class="subhead">High Education Details</th>
            </tr>
            <tr>
                <td colspan="2">School Name :
                    <?php echo "$schoolName" ?>
                </td>
                <td colspan="2">Passout year :
                    <?php echo "$schoolYear" ?>
                </td>
            </tr>
            <tr>
                <td colspan="4">School Board Name :
                    <?php echo "$schoolBoardName" ?>
                </td>
            </tr>
            <tr>
                <th colspan="4" class="subhead">Secondary Education Details</th>
            </tr>
            <tr>
                <td colspan="2">Junior College Name :
                    <?php echo "$jrCollegeName" ?>
                </td>
                <td colspan="2">Stream :
                    <?php echo "$stream" ?>
                </td>
            </tr>
            <tr>
                <td colspan="2">Junior Board Name :
                    <?php echo "$jrCollegeBoardName" ?>
                </td>
                <td colspan="2">Junior College Passout year :
                    <?php echo "$jrCollegeYear" ?>
                </td>
            </tr>
            <tr>
                <th colspan="4" class="subhead">Graduation Details</th>
            </tr>
            <tr>
                <td colspan="2">Degree Name :
                    <?php echo "$graduationDegree" ?>
                </td>
                <td colspan="2">Graduation year :
                    <?php echo "$graduationYear"; ?>

                </td>
            </tr>
            <tr>
                <td colspan="4">Graduation Name:
                    <?php echo "$graduationInstitution" ?>
                </td>
            </tr>
        </table>

    <?php } else {
        echo "No data found";
    }
    ?>


</body>

</html>