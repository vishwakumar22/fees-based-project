<?php
    $servername= "localhost";
    $username = "root";
    $password ="";
    $database = "admin";
    $conn = mysqli_connect($servername, $username, $password, $database);
    if ($conn -> connect_error)
    {
        die ("Connection failed : " . $conn->connect_error);
    }
    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if (isset($_POST["loginSubmit"]))
        {
            $loginname = $_POST["loginemail"];
            $loginPassword  = $_POST["loginpass"];
            //$hashedPassword = password_hash($loginPassword, PASSWORD_DEFAULT);
            $sql = "SELECT * FROM `adminsignup` WHERE adminemail = '$loginname' AND passcode = '$loginPassword'";
            $result = mysqli_query($conn, $sql);
            if($result && mysqli_num_rows($result) > 0)
            {
                header("Location: dashboard.html");
            }
            else
            {
                echo "Wrong email or password";
            }
        
            
        }
        elseif(isset($_POST["signupSubmit"]))
        {
            $signupemail = $_POST["signupemail"];
            $signuppass = $_POST["signuppass1"];
            $signuppass2 = $_POST["signuppass2"];
            if(strlen($signuppass) === strlen($signuppass2) && $signuppass === $signuppass2)
            {
            //$hashedPassword = password_hash($signuppass, PASSWORD_DEFAULT);
                $sql = "INSERT INTO `adminsignup` (adminemail , passcode)VALUES ('$signupemail', '$signuppass')";
                $result = mysqli_query($conn, $sql);
                if ($result)
                {
                    echo "record inserted ";
                }
            }
            else
            {
                echo " failed to insert";
            }
        }
    }

    $conn -> close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,
						initial-scale=1.0">
    <title>Login and signup</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            height: 100vh;
            width: 100vw;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            gap: 30px;
            background-color: rgb(231, 231, 231);
        }

        .container {
            height: 450px;
            width: 400px;
            background-color: white;
            box-shadow: 8px 8px 20px rgb(5, 68, 104);
            position: relative;
            overflow: hidden;

        }

        .btn {
            height: 60px;
            width: 300px;
            margin: 20px auto;
            box-shadow: 10px 10px 30px rgb(5, 68, 104);
            border-radius: 50px;
            display: flex;
            justify-content: space-around;
            align-items: center;
            background-color: #d6d4e0;
            color: white;
        }

        .login,
        .signup {
            font-size: 20px;
            border: none;
            outline: none;
            background-color: transparent;
            position: relative;
            cursor: pointer;
            color: white;
        }

        .slider {
            height: 60px;
            width: 125px;
            border-radius: 50px;
            background-color: rgb(5, 68, 104);
            position: absolute;
            top: 20px;
            left: 50px;
            transition: all 0.5s ease-in-out;
        }

        .moveslider {
            left: 225px;
        }

        .form-section {
            height: 300px;
            width: 300px;
            padding: 10px;
            display: flex;
            position: relative;
            top: 80px;
            left: 10px;
            color: white;
            transition: all 0.5s ease-in-out;
        }

        .form-section-move {
            left: -370px;
        }

        .login-box,
        .signup-box {
            height: 40px;
            width: 400px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 0px 40px;

        }

        .signup-box {
            position: relative;
            right: 25px;
            top: 60px;
            gap: 30px;

        }

        .login-box {
            gap: 40px;
            position: relative;
            top: 40px;
            right: 20px;
        }

        .ele {
            height: 60px;
            width: 300px;
            outline: none;
            border: none;
            color: rgb(77, 77, 77);
            background-color: rgb(240, 240, 240);
            border-radius: 50px;
            padding-left: 30px;
            font-size: large;
        }

        input {
            padding: 10px;
        }

        .clkbtn {
            height: 60px;
            width: 150px;
            border-radius: 50px;
            background-color: rgb(5, 68, 104);
            font-size: 22px;
            border: none;
            cursor: pointer;
            color: white;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="slider"></div>
        <div class="btn">
            <button class="login">Login</button>
            <button class="signup">Signup</button>
        </div>
        <div class="form-section">
            <form  name="login" method="post" action="login.php">
                <div class="login-box">
                    <input type="email" class="email ele" placeholder="youremail@email.com" name="loginemail">
                    <input type="password" class="password ele" name="loginpass" placeholder="password">
                    <input type="submit" class="clkbtn" value="login" name="loginSubmit">
                </div>
            </form>
            <form  name="signup" method="post" action="login.php">
                <div class="signup-box">
                    <input type="email" class="email ele" placeholder="youremail@email.com" name="signupemail">
                    <input type="password" class="password ele" placeholder="password" name="signuppass1">
                    <input type="password" class="password ele" placeholder="Confirm password" name="signuppass2">
                    <button class="clkbtn" name="signupSubmit">Signup</button>
                </div>
            </form>
        </div>
    </div>
    <script>
        let signup = document.querySelector(".signup");
        let login = document.querySelector(".login");
        let slider = document.querySelector(".slider");
        let formSection = document.querySelector(".form-section");

        signup.addEventListener("click", () => {
            slider.classList.add("moveslider");
            formSection.classList.add("form-section-move");
        });

        login.addEventListener("click", () => {
            slider.classList.remove("moveslider");
            formSection.classList.remove("form-section-move");
        });
     
    </script>
</body>

</html>