<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "payment";
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("connection failed : " . $conn->connect_error);
}
$data = array();

if (isset($_POST["find"])) {
    $year = $_POST["year"];
    $course = $_POST["course"];
    $sql = "SELECT * FROM `userdata` WHERE graduation_year= '$year' AND graduation_degree = '$course'";
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = $row;
        }
    } else {
        echo "No data found";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search course</title>
    <style>
        input {
            padding: 10px;
            width: 300px;
            margin-left: 10px;
        }

        label {
            margin-left: 20px;
        }

        button {
            padding: 5px;
            background-color: rgb(5, 68, 104);
            color: white;
            margin: 10px;
            margin-left: 40px;
        }
    </style>
</head>

<body>
    <a href="dashboard.html"><button>Dashboard</button></a>
    <form method="post" action="searchcourse.php">
        <div>
            <label for="year">Enter Year: </label>
            <input type="search" placeholder="Enter the year eq:fy/sy/ty" name="year" id="year">

            <label for="course">Enter course name: </label>
            <input type="search" placeholder="Search using eg:bsc-cs/bms...." name="course" id="course">
            <button name="find">Search</button>
        </div>
    </form>
    <?php if (!empty($data)) { ?>
        <table border="2">
            <tr>
                <th>Name</th>
                <th>Gender</th>
                <th>Course</th>
                <th>Year</th>
                <th>Email</th>
            </tr>
            <?php
            foreach ($data as $row) {
                echo "<tr>";
                echo "<td>" . $row["first_name"] . " " . $row["last_name"] . "</td>";
                echo "<td>" . $row["gender"] . "</td>";
                echo "<td>" . $row["graduation_degree"] . "</td>";
                echo "<td>" . $row["graduation_year"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "</tr>";
            }
            ?>
        </table>
    <?php } ?>
</body>

</html>
