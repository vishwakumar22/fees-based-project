<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "admin";
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("connection failed : " . $conn->connect_error);
}
$addMessage = "";
$editMessage = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["submit"])) {
        $course = $_POST["course"];
        $course_year = $_POST["year"];
        $amount = $_POST["fee"];
        $sql = "SELECT * FROM `fees` WHERE course = '$course' AND course_year = '$course_year'";
        $result = mysqli_query($conn, $sql);
        if ($result && mysqli_num_rows($result) == 0)
        {
            $sql = "INSERT INTO `fees` (course,course_year, fee_amount) VALUES ('$course','$course_year', '$amount')";
            $result = mysqli_query($conn, $sql);
            if ($result) {
                $addMessage = "Added the course and fee";
            } else {
                $addMessage = "Failed to add";
            }
        }
        else{
            $addMessage= "course Name already exit";
        }
       
    } elseif (isset($_POST["change"])) {
        $ecourse = $_POST["editcourse"];
        $ecourse_year = $_POST["eyear"];
        $fee = $_POST["editfee"];
        $sql = "UPDATE `fees` SET fee_amount = '$fee' WHERE course = '$ecourse' AND course_year = '$ecourse_year' ";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            $editMessage = "Edited the fee";
        } else {
            $editMessage = "Failed to edit";
        }
    }
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fees Amount</title>
    <style>
        * {
            margin: 0px;
            padding: 0px;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            height: 100vh;
            width: 100vw;
            display: flex;
            justify-content: center;
            align-items: center;
            color:white;
            flex-direction: column;
            gap: 30px;
            background-color: white;
        }

        .container {
            height: 500px;
            width: 800px;
            background-color: white;
            box-shadow: 8px 8px 20px rgb(5, 68, 104);;
            position: relative;
            overflow: hidden;
            border-radius: 30px;
        }

        .btn {
            height: 60px;
            width: 800px;
            margin: 0px auto;
            box-shadow: 10px 10px 30px rgb(5, 68, 104);;
            border-radius: 50px;
            display: flex;
            justify-content: space-around;
            align-items: center;
            color: white;
        }

        .add,
        .edit {
            font-size: 20px;
            border: none;
            outline: none;
            background-color: transparent;
            position: relative;
            cursor: pointer;
        }
        .slider {
            height: 60px;
            width: 400px;
            border-radius: 50px;
            background-color: rgb(5, 68, 104);
            position: absolute;
            transition: all 0.5s ease-in-out;
        }

        .moveslider {
            left: 400px;
        }
        .form-section {
            height: 400px;
            width: 800px;
            padding: 10px;
            display: flex;
            position: relative;
            top: 150px;
            left: 200px;
            transition: all 0.5s ease-in-out;
        }

        .form-section-move {
            left: -400px;
        }

        .add-box,
        .edit-box {
            height: 40px;
            width: 400px;
            margin-top:40px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 0px 40px;

        }
        .edit-box{
            position: relative;
            left:250px;
        }
        .text-field{
            padding: 10px;
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 10px;
        }
        label{
            color:rgb(5, 68, 104);
            font-size: 30px;
        }
        .submit-button {
            height: 40px;
            width: 150px;
            border-radius: 50px;
            background-color: rgb(5, 68, 104);
            font-size: 22px;
            border: none;
            cursor: pointer;
            margin-top: 30px;
        }
        .click{
            height: 40px;
            width: 200px;
            border-radius: 50px;
            background-color: rgb(5, 68, 104);
            font-size: 22px;
            border: none;
            cursor: pointer;
        }
        .edit-message, .add-message{
            text-align: center;
            margin-top: 10px;
            color: rgb(5, 68, 104);
            font-size: 20px;
            margin-bottom: 20px;
        }
    </style>

</head>

<body>
    
    <div class="container">
        <div class="slider"></div>
        <div class="btn">
            <button class="add">Add Course and Fee</button>
            <button class="edit">Edit Course</button>
        </div>
        
        <div class="form-section">
            <form name="add" method="post" action="fees.php">
                <div class="add-box">
                <p class="add-message"><?php echo $addMessage; ?></p>
                    <div class="form-group">
                        <label for="course">Course Name:</label>
                        <input type="text" class="text-field" name="course" id="course" required>
                    </div>
                    <div class="form-group">
                        <label for="year">Course Year:</label>
                        <input type="text" class="text-field" name="year" id="year" required>
                    </div>
                    <div class="form-group">
                        <label for="fee">Fee Amount:</label>
                        <input type="number" class="text-field" name="fee" id="fee" required>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="submit-button" name="submit">Submit</button>
                    </div>
                </div>
            </form>
            <form name="edit" method="post" action="fees.php">
                <div class="edit-box">
                <p class="edit-message"><?php echo $editMessage; ?></p>
                    <div class="form-group">
                        <label for="course">Course Name:</label>
                        <input type="text" class="text-field" name="editcourse" id="course" required>
                    </div>
                    <div class="form-group">
                        <label for="year">Course Year:</label>
                        <input type="text" class="text-field" name="eyear" id="year" required>
                    </div>
                    <div class="form-group">
                        <label for="fee">Fee Amount:</label>
                        <input type="number" class="text-field" name="editfee" id="fee" required>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="submit-button" name="change">Submit</button>
                    </div>
                </div>
            </form>
        </div>
        
    </div>
    <a href="dashboard.html"><button class="click">Back To Dashboard</button></a>
    <script>
        let edit = document.querySelector(".edit");
        let add = document.querySelector(".add");
        let slider = document.querySelector(".slider");
        let formSection = document.querySelector(".form-section");

        edit.addEventListener("click", () => {
            slider.classList.add("moveslider");
            formSection.classList.add("form-section-move");
        });

        add.addEventListener("click", () => {
            slider.classList.remove("moveslider");
            formSection.classList.remove("form-section-move");
        });

    </script>

</body>

</html>