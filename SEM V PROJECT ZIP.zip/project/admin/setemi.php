<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "admin";
$conn = mysqli_connect($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (isset($_POST["submit"])) {
    $course = $_POST["coursename"];
    $course_year = $_POST["courseyear"];
    $firstamount = $_POST["firstamount"];
    $date1 = $_POST["date1"];
    $secondamount = $_POST["secondamount"];
    $date2 = $_POST["date2"];
    $thirdamount = $_POST["thirdamount"];
    $date3 = $_POST["date3"];
    $sql = "SELECT * FROM `emi_table` WHERE course_name = '$course' AND course_year = '$course_year'";
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) ==0) {
        $sql = "INSERT INTO `emi_table`(course_name,course_year, first_installment_amount, first_installment_date, second_installment_amount, second_installment_date, third_installment_amount, third_installment_date ) VALUES ('$course','$course_year', '$firstamount', '$date1', '$secondamount', '$date2', '$thirdamount', '$date3')";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            echo "Data inserted";
        } else {
            echo "data not inserted due to some problem";
        }
    } 
    else {
        $sql = "UPDATE `emi_table` SET first_installment_amount= '$firstamount', first_installment_date='$date1', second_installment_amount = '$secondamount', second_installment_date='$date2', third_installment_amount='$thirdamount', third_installment_date='$date3' WHERE course_name = '$course' AND course_year ='$course_year'";
        $result = mysqli_query($conn, $sql);
        if($result)
        {
            echo "record updated succesfully";
        }
        else{
            echo "record not updated";
        }
    }

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set EMI</title>
</head>

<body>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            .click {
                height: 40px;
                width: 150px;
                border-radius: 50px;
                background-color: rgb(5, 68, 104);
                font-size: 15px;
                color: white;
                border: none;
                cursor: pointer;
                position: relative;
                top: 20px;
                left: 500px;
            }

            table {
                margin: auto;
            }

            th {
                padding: 13px;
            }

            td,
            input {
                padding: 5px;
            }
        </style>
    </head>

    <body>
        <form action="setemi.php" method="post">
            <table border=2>
                <tr>
                    <th colspan="2">Name of the course</th>
                    <th colspan="2">Ist Installment </th>
                    <th colspan="2">IInd Installment </th>
                    <th colspan="2">IIIrd Installment </th>
                </tr>
                <tr>
                    <th colspan="2"></th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Amount</th>
                </tr>
                <tr>
                    <td><input type="text" placeholder="Course name" name="coursename"></td>
                    <td><input type="text" placeholder="Course year" name="courseyear"></td>
                    <td><input type="date" name="date1"></td>
                    <td><input type="number" placeholder="Ist Installment Amount " name="firstamount"></td>
                    <td><input type="date" name="date2"></td>
                    <td><input type="number" placeholder="IInd Installment Amount " name="secondamount"></td>
                    <td><input type="date" name="date3"></td>
                    <td><input type="number" placeholder="IIIrd Installment Amount " name="thirdamount"></td>
                </tr>
            </table>
            <button name="submit" class="click">Enter data in DB</button>
        </form>
    </body>

    </html>
</body>

</html>